(function () {
  function forceGo(url) {
    window.location.assign(url);
  }

  function makeBtn(id, text, iconClass, bg, url) {
    var a = document.createElement("a");
    a.id = id;
    a.href = url;
    a.className = "nav-link";
    a.setAttribute("role", "button");
    a.setAttribute("tabindex", "0");

    a.style.cssText =
      "background-color:" + bg + " !important;" +
      "color:#fff !important;" +
      "margin:5px !important;" +
      "border-radius:6px !important;" +
      "pointer-events:auto !important;" +
      "cursor:pointer !important;" +
      "position:relative !important;" +
      "z-index:9999 !important;";

    a.innerHTML =
      '<i class="nav-icon ' + iconClass + '"></i>' +
      '<p style="margin:0;">' + text + "</p>";

    a.addEventListener("click", function (e) {
      e.preventDefault();
      e.stopPropagation();
      forceGo(url);
    }, true);

    a.addEventListener("keydown", function (e) {
      if (e.key === "Enter" || e.key === " ") {
        e.preventDefault();
        e.stopPropagation();
        forceGo(url);
      }
    }, true);

    var li = document.createElement("li");
    li.className = "nav-item";
    li.style.cssText = "pointer-events:auto !important; position:relative !important; z-index:9999 !important;";
    li.appendChild(a);
    return li;
  }

  function clean(el) {
    if (!el) return;
    el.classList.remove("disabled");
    el.removeAttribute("aria-disabled");
    el.style.pointerEvents = "auto";
  }

  function inject() {
    var menu =
      document.querySelector("ul.nav.nav-pills.nav-sidebar") ||
      document.querySelector("ul.nav-sidebar") ||
      document.querySelector(".nav-sidebar");

    if (!menu) return;

    if (!document.getElementById("nav-admin-section-link")) {
      var liAdmin = makeBtn(
        "nav-admin-section-link",
        "Өгөгдөл бүртгэх (Админ)",
        "fas fa-edit",
        "#007bff",
        "/django-admin/"
      );
      menu.insertBefore(liAdmin, menu.firstChild);
      clean(liAdmin);
      clean(liAdmin.querySelector("a"));
    }

    if (!document.getElementById("nav-dashboard-graph-link")) {
      var liGraph = makeBtn(
        "nav-dashboard-graph-link",
        "График Тайлан",
        "fas fa-chart-pie",
        "#28a745",
        "/admin/dashboard/graph/"
      );
      menu.insertBefore(liGraph, menu.firstChild);
      clean(liGraph);
      clean(liGraph.querySelector("a"));
    }

    if (!document.getElementById("nav-dashboard-table-link")) {
      var liTable = makeBtn(
        "nav-dashboard-table-link",
        "Dashboard",
        "fas fa-table",
        "#0d6efd",
        "/admin/dashboard/table/"
      );
      menu.insertBefore(liTable, menu.firstChild);
      clean(liTable);
      clean(liTable.querySelector("a"));
    }
  }

  document.addEventListener("DOMContentLoaded", function () {
    inject();
    setInterval(inject, 700);
  });
})();
