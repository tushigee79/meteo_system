(function () {
  function findKindSelect() {
    // Төрөл талбарын нэр төслөөс хамаараад өөр байж болдог тул олон хувилбар хайна
    const candidates = ["#id_kind", "#id_device_type", "#id_device_kind", "#id_type"];
    for (const sel of candidates) {
      const el = document.querySelector(sel);
      if (el) return el;
    }
    // fallback: эхний select
    return document.querySelector("select");
  }

  function normalizeKind(v) {
    if (!v) return "";
    const s = String(v).toLowerCase();

    // Монгол UI дээрх утгууд
    if (s.includes("багаж")) return "DEVICE";
    if (s.includes("эталон")) return "ETALON";
    if (s.includes("том")) return "SYSTEM";      // ✅ Том систем
    if (s.includes("систем")) return "SYSTEM";   // ✅ Том систем
    if (s.includes("бусад")) return "OTHER";

    // enum утгууд
    if (s === "device") return "DEVICE";
    if (s === "etalon") return "ETALON";
    if (s === "system") return "SYSTEM";         // ✅
    if (s === "other") return "OTHER";

    return v;
  }

  function isValidKind(k) {
    return ["DEVICE", "ETALON", "SYSTEM", "OTHER"].includes(k);
  }

  function reloadWithKind(kindValue) {
    if (!isValidKind(kindValue)) {
      console.warn("Unknown device kind:", kindValue);
      return;
    }
    const url = new URL(window.location.href);
    url.searchParams.set("kind", kindValue);
    window.location.href = url.toString();
  }

  document.addEventListener("DOMContentLoaded", function () {
    const kindSelect = findKindSelect();
    if (!kindSelect) return;

    // анх орж ирэхэд kind параметр байхгүй бол автоматаар set хийнэ
    const url = new URL(window.location.href);
    if (!url.searchParams.get("kind")) {
      const initialKind = normalizeKind(kindSelect.value);
      if (isValidKind(initialKind)) {
        url.searchParams.set("kind", initialKind);
        window.history.replaceState({}, "", url.toString());
      }
    }

    kindSelect.addEventListener("change", function () {
      const kind = normalizeKind(kindSelect.value);
      reloadWithKind(kind);
    });
  });
})();
