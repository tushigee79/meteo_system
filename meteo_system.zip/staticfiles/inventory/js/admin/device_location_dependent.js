(function () {
  function qs(sel) { return document.querySelector(sel); }

  function baseUrlFor(extra) {
    // .../device/add/  эсвэл .../device/123/change/  -> .../device/
    const p = window.location.pathname;
    const root = p.replace(/\/add\/$/, "/").replace(/\/\d+\/change\/$/, "/");
    return root + extra;
  }

  function loadSums(aimagId) {
    const sumSel = qs("#id_sum_pick");
    if (!sumSel) return;

    const url = baseUrlFor("sum-options/?aimag_id=" + encodeURIComponent(aimagId || ""));
    fetch(url, { headers: { "X-Requested-With": "XMLHttpRequest" } })
      .then(r => r.json())
      .then(data => {
        sumSel.innerHTML = '<option value="">---------</option>';
        (data.items || []).forEach(it => {
          const opt = document.createElement("option");
          opt.value = it.id;
          opt.textContent = it.text;
          sumSel.appendChild(opt);
        });
        // sum солигдсоны дараа location дахин ачаална
        loadLocations(aimagId, "");
      })
      .catch(() => {});
  }

  function loadLocations(aimagId, sumId) {
    const locSel = qs("#id_location");
    if (!locSel) return;

    const url = baseUrlFor("location-options/?aimag_id=" + encodeURIComponent(aimagId || "") + "&sum_id=" + encodeURIComponent(sumId || ""));
    fetch(url, { headers: { "X-Requested-With": "XMLHttpRequest" } })
      .then(r => r.json())
      .then(data => {
        const current = locSel.value;
        locSel.innerHTML = '<option value="">---------</option>';
        (data.items || []).forEach(it => {
          const opt = document.createElement("option");
          opt.value = it.id;
          opt.textContent = it.text;
          locSel.appendChild(opt);
        });
        if (current) locSel.value = current;
      })
      .catch(() => {});
  }

  document.addEventListener("DOMContentLoaded", function () {
    const aimagSel = qs("#id_aimag_pick");
    const sumSel = qs("#id_sum_pick");
    if (!aimagSel || !sumSel) return;

    // initial
    loadSums(aimagSel.value);

    aimagSel.addEventListener("change", function () {
      loadSums(aimagSel.value);
    });

    sumSel.addEventListener("change", function () {
      loadLocations(aimagSel.value, sumSel.value);
    });
  });
})();
