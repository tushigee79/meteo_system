(function () {
  function qs(sel) { return document.querySelector(sel); }

  function loadCatalog(kind) {
    const sel = qs("#id_catalog_item");
    if (!sel) return;

    const url = window.location.pathname.replace(/\/change\/.*$/, "/") + "catalog-options/?kind=" + encodeURIComponent(kind || "");
    fetch(url, { headers: { "X-Requested-With": "XMLHttpRequest" } })
      .then(r => r.json())
      .then(data => {
        const current = sel.value;
        sel.innerHTML = '<option value="">---------</option>';
        (data.items || []).forEach(it => {
          const opt = document.createElement("option");
          opt.value = it.id;
          opt.textContent = it.text;
          sel.appendChild(opt);
        });
        // боломжтой бол өмнөх сонголтыг хадгална
        if (current) sel.value = current;
      })
      .catch(() => {});
  }

  document.addEventListener("DOMContentLoaded", function () {
    const kindSel = qs("#id_kind");
    if (!kindSel) return;

    loadCatalog(kindSel.value);
    kindSel.addEventListener("change", function () {
      loadCatalog(kindSel.value);
    });
  });
})();
