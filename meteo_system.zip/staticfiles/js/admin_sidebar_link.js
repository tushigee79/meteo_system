(function () {
  function injectLinks() {
    var menu = document.querySelector("ul.nav.nav-pills.nav-sidebar");
    if (!menu) return false;

    // 1. "График Тайлан" товчийг НОГООН өнгөөр нэмэх
    if (!document.getElementById("nav-dashboard-custom-link")) {
      var liDash = document.createElement("li");
      liDash.className = "nav-item";
      liDash.innerHTML = `
        <a href="/admin/dashboard/" class="nav-link" id="nav-dashboard-custom-link" style="background-color: #28a745 !important; color: white !important; margin: 5px !important; border-radius: 4px;">
          <i class="nav-icon fas fa-chart-pie"></i>
          <p>График Тайлан</p>
        </a>`;
      menu.prepend(liDash);
    }

    // 2. "Өгөгдөл бүртгэх" товчийг ЦЭНХЭР өнгөөр нэмэх
    if (!document.getElementById("nav-admin-section-link")) {
      var liAdmin = document.createElement("li");
      liAdmin.className = "nav-item";
      liAdmin.innerHTML = `
        <a href="/django-admin/" class="nav-link" id="nav-admin-section-link" style="background-color: #007bff !important; color: white !important; margin: 5px !important; border-radius: 4px;">
          <i class="nav-icon fas fa-edit"></i>
          <p>Өгөгдөл бүртгэх (Админ)</p>
        </a>`;
      menu.prepend(liAdmin);
    }
    return true;
  }

  // Хуудас ачаалагдах болон шилжих бүрт товчнууд байгаа эсэхийг байнга шалгана
  setInterval(injectLinks, 500);
})();