# inventory/admin.py
import csv
import json

from django.contrib import admin
from django import forms
from django.http import HttpResponse, JsonResponse
from django.template.response import TemplateResponse
from django.urls import path, reverse
from django.utils.html import format_html
from django.utils.timezone import now
from django.db.models import Q

from .models import (
    InstrumentCatalog,
    Aimag, SumDuureg, Organization,
    Location, Device,
    SparePartOrder, SparePartItem,
    UserProfile, AuthAuditLog,
)

# ============================================================
# ✅ Instrument Catalog
# ============================================================
@admin.register(InstrumentCatalog)
class InstrumentCatalogAdmin(admin.ModelAdmin):
    list_display = ("kind", "code", "name_mn", "unit", "is_active", "sort_order")
    list_filter = ("kind", "is_active")
    search_fields = ("code", "name_mn")
    ordering = ("sort_order", "kind", "name_mn")


# ============================================================
# ✅ Aimag / SumDuureg
# ============================================================
@admin.register(Aimag)
class AimagAdmin(admin.ModelAdmin):
    list_display = ("name", "code")
    search_fields = ("name", "code")
    ordering = ("name",)


@admin.register(SumDuureg)
class SumDuuregAdmin(admin.ModelAdmin):
    list_display = ("name", "aimag", "code", "is_ub_district")
    list_filter = ("aimag", "is_ub_district")
    search_fields = ("name", "code", "aimag__name")
    autocomplete_fields = ("aimag",)
    ordering = ("aimag__name", "name")


# ============================================================
# ✅ Organization
# ============================================================
@admin.register(Organization)
class OrganizationAdmin(admin.ModelAdmin):
    list_display = ("name", "org_type", "aimag", "is_ub")
    list_filter = ("org_type", "aimag", "is_ub")
    search_fields = ("name", "aimag__name")
    autocomplete_fields = ("aimag",)
    ordering = ("name",)


# ============================================================
# ✅ Location Admin (cascade + map view + CSV template)
# ============================================================
@admin.register(Location)
class LocationAdmin(admin.ModelAdmin):

    def get_list_display(self, request):
        wanted = [
            "name",
            "location_type",
            "type",
            "aimag_ref",
            "sum_ref",
            "wmo_index",
            "ub_district",
            "responsible_org",
            "latitude",
            "longitude",
        ]
        existing = {f.name for f in self.model._meta.get_fields() if hasattr(f, "name")}
        cols = [f for f in wanted if f in existing]
        cols.append("view_map_link")
        return tuple(cols)

    # --- Хариуцагч: дүрэмтэйгээр байгууллага сонгох ---
    def resolve_responsible_organization(self, loc):
        """Return Organization instance or None based on business rules."""
        name_lc = (getattr(loc, "name", "") or "").strip().lower()

        # 1) Морин-Уул -> НЦУТ (CENTER)
        if "морин" in name_lc and "уул" in name_lc:
            org = Organization.objects.filter(org_type="CENTER").order_by("name").first()
            if org:
                return org
            return Organization.objects.filter(name__icontains="НЦУТ").order_by("name").first()

        # 2) Зүрх-Уул -> ЦУОШГ
        if ("зүрх" in name_lc and "уул" in name_lc) or ("зүрх-уул" in name_lc):
            org = Organization.objects.filter(name__icontains="ЦУОШГ").order_by("name").first()
            if org:
                return org

        # 3) Эталон багаж -> БОХЗТЛ (CAL_LAB)
        try:
            has_etalon = Device.objects.filter(location=loc, kind=InstrumentCatalog.Kind.ETALON).exists()
        except Exception:
            has_etalon = False

        if has_etalon or ("бохзт" in name_lc) or ("бохзтл" in name_lc):
            org = Organization.objects.filter(org_type="CAL_LAB").order_by("name").first()
            if org:
                return org
            return Organization.objects.filter(name__icontains="БОХЗТ").order_by("name").first()

        # 4) Location.owner_org байгаа бол тэрийг нь үзүүл
        owner = getattr(loc, "owner_org", None)
        if owner:
            return owner

        # 5) default: тухайн аймгийн УЦУОШТ (OBS_CENTER)
        aimag = getattr(loc, "aimag_ref", None)
        if aimag:
            org = Organization.objects.filter(org_type="OBS_CENTER", aimag=aimag).order_by("name").first()
            if org:
                return org
            # fallback: aimag-тай ямар ч байгууллага байж болно
            return Organization.objects.filter(aimag=aimag).order_by("name").first()

        return None

    def responsible_org(self, obj):
        org = self.resolve_responsible_organization(obj)
        return org.name if org else "-"

    responsible_org.short_description = "Хариуцагч"

    list_filter = ("aimag_ref", "sum_ref", "owner_org")
    search_fields = ("name", "wmo_index", "district_name")
    autocomplete_fields = ("aimag_ref", "sum_ref", "owner_org")

    def view_map_link(self, obj):
        url = reverse("admin:inventory_location_location_map_one", args=[obj.pk])
        return format_html('<a class="button" href="{}">Харах</a>', url)

    view_map_link.short_description = "Харах"

    def get_urls(self):
        urls = super().get_urls()
        custom = [
            path("<int:pk>/map/", self.admin_site.admin_view(self.location_map_one),
                 name="inventory_location_location_map_one"),
            path("sums-by-aimag/", self.admin_site.admin_view(self.sums_by_aimag),
                 name="location_sums_by_aimag"),
            path("download-aimag-template/", self.admin_site.admin_view(self.download_aimag_template),
                 name="download_aimag_template"),
        ]
        return custom + urls

    def sums_by_aimag(self, request):
        aimag_id = request.GET.get("aimag_id")
        if not aimag_id:
            return JsonResponse({"results": []})

        qs = SumDuureg.objects.filter(aimag_id=aimag_id).order_by("name")
        try:
            aimag = Aimag.objects.get(id=aimag_id)
            if "улаанбаатар" in (aimag.name or "").lower():
                qs = qs.filter(is_ub_district=True)
        except Aimag.DoesNotExist:
            pass

        return JsonResponse({"results": [{"id": s.id, "text": s.name} for s in qs]})

    def download_aimag_template(self, request):
        resp = HttpResponse(content_type="text/csv; charset=utf-8")
        resp["Content-Disposition"] = 'attachment; filename="aimag_template.csv"'
        resp.write("\ufeff")
        w = csv.writer(resp)
        w.writerow(["aimag", "sum", "code"])
        w.writerow(["Улаанбаатар", "Баянзүрх", ""])
        return resp

    def location_map_one(self, request, pk: int):
        loc = Location.objects.filter(pk=pk).first()
        if not loc:
            return HttpResponse("Location not found", status=404)

        device_count = Device.objects.filter(location=loc).count()

        points = []
        lat = getattr(loc, "latitude", None)
        lon = getattr(loc, "longitude", None)

        if lat is not None and lon is not None:
            try:
                points.append({
                    "id": loc.id,
                    "name": getattr(loc, "name", "") or "",
                    "aimag": str(getattr(loc, "aimag_ref", "") or ""),
                    "type": (
                        getattr(loc, "location_type", None)
                        or getattr(loc, "type", None)
                        or ""
                    ),
                    "lat": float(lat),
                    "lon": float(lon),
                    "device_count": device_count,
                })
            except Exception:
                pass

        ctx = dict(
            self.admin_site.each_context(request),
            title=f"Байршил газрын зураг: {getattr(loc, 'name', '')}",
            locations_json=json.dumps(points, ensure_ascii=False),
        )

        return TemplateResponse(
            request,
            "admin/inventory/location/location_map_one.html",
            ctx,
        )

    class Media:
        js = ("inventory/location_cascade.js",)


# ============================================================
# ✅ Device (catalog filter + CSV export + aimag scope)
# ============================================================
# ============================================================
# ✅ Device (kind -> catalog filter + location cascade + CSV export + aimag scope)
# ============================================================
class DeviceAdminForm(forms.ModelForm):
    aimag = forms.ModelChoiceField(
        queryset=Aimag.objects.all().order_by("name"),
        required=False,
        label="Аймаг/Нийслэл",
    )
    sumduureg = forms.ModelChoiceField(
        queryset=SumDuureg.objects.none(),
        required=False,
        label="Сум/Дүүрэг",
    )

    class Meta:
        model = Device
        fields = "__all__"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # ----- initial aimag/sum from existing location -----
        loc = getattr(self.instance, "location", None)
        if loc and getattr(loc, "aimag_ref", None):
            self.fields["aimag"].initial = loc.aimag_ref
            self.fields["sumduureg"].queryset = SumDuureg.objects.filter(aimag=loc.aimag_ref).order_by("name")
            if getattr(loc, "sum_ref", None):
                self.fields["sumduureg"].initial = loc.sum_ref

        # ----- if POST, set sumduureg queryset by posted aimag -----
        aimag_id = (self.data.get("aimag") or "").strip()
        if aimag_id:
            qs = SumDuureg.objects.filter(aimag_id=aimag_id).order_by("name")
            # УБ бол зөвхөн 9 дүүрэг
            aimag_name = Aimag.objects.filter(id=aimag_id).values_list("name", flat=True).first() or ""
            if "улаанбаатар" in (aimag_name or "").lower():
                qs = qs.filter(is_ub_district=True)
            self.fields["sumduureg"].queryset = qs

        # ----- catalog_item queryset filter by kind (for initial render) -----
        kind = None
        if "kind" in self.data:
            kind = self.data.get("kind") or None
        if not kind and getattr(self.instance, "kind", None):
            kind = self.instance.kind

        if "catalog_item" in self.fields:
            qs = InstrumentCatalog.objects.all()
            if kind:
                qs = qs.filter(kind=kind)
            self.fields["catalog_item"].queryset = qs.order_by("sort_order", "name_mn")


@admin.register(Device)
class DeviceAdmin(admin.ModelAdmin):
    form = DeviceAdminForm

    # ✅ helper fields (aimag, sumduureg) + real location
    fieldsets = (
        (None, {"fields": ("serial_number", "kind", "catalog_item", "other_name")}),
        ("Байршил", {"fields": ("aimag", "sumduureg", "location")}),
        ("Бусад", {"fields": ("status", "installation_date", "lifespan_years")}),
    )

    list_display = (
        "serial_number",
        "kind",
        "catalog_item",
        "other_name",
        "location",
        "status",
        "installation_date",
        "lifespan_years",
    )
    list_filter = (
        "kind",
        "status",
        "location__aimag_ref",
        "location__location_type",
    )
    search_fields = (
        "serial_number",
        "other_name",
        "catalog_item__name_mn",
        "catalog_item__code",
        "location__name",
        "location__wmo_index",
    )
    autocomplete_fields = ("catalog_item", "location")
    ordering = ("serial_number",)

    def get_urls(self):
        urls = super().get_urls()
        custom = [
            # ✅ ДЦУБ жагсаалт шүүх
            path("catalog-by-kind/", self.admin_site.admin_view(self.catalog_by_kind), name="device_catalog_by_kind"),
            # ✅ Байршил cascade
            path("sums-by-aimag/", self.admin_site.admin_view(self.sums_by_aimag), name="device_sums_by_aimag"),
            path("locations-by-sum/", self.admin_site.admin_view(self.locations_by_sum), name="device_locations_by_sum"),
            # ✅ CSV export
            path("export-csv/", self.admin_site.admin_view(self.export_devices_csv), name="export_devices_csv"),
        ]
        return custom + urls

    def catalog_by_kind(self, request):
        kind = (request.GET.get("kind") or "").strip()
        q = (request.GET.get("q") or "").strip()

        qs = InstrumentCatalog.objects.all()
        if kind:
            qs = qs.filter(kind=kind)
        if q:
            qs = qs.filter(Q(name_mn__icontains=q) | Q(code__icontains=q))

        qs = qs.order_by("sort_order", "name_mn")[:200]
        return JsonResponse({"results": [{"id": x.id, "text": x.name_mn} for x in qs]})

    def sums_by_aimag(self, request):
        aimag_id = request.GET.get("aimag_id")
        if not aimag_id:
            return JsonResponse({"results": []})

        qs = SumDuureg.objects.filter(aimag_id=aimag_id).order_by("name")

        aimag_name = Aimag.objects.filter(id=aimag_id).values_list("name", flat=True).first() or ""
        if "улаанбаатар" in (aimag_name or "").lower():
            qs = qs.filter(is_ub_district=True)

        return JsonResponse({"results": [{"id": s.id, "text": s.name} for s in qs]})

    def locations_by_sum(self, request):
        sum_id = request.GET.get("sum_id")
        if not sum_id:
            return JsonResponse({"results": []})

        qs = Location.objects.filter(sum_ref_id=sum_id).order_by("name")[:300]
        return JsonResponse({"results": [{"id": x.id, "text": x.name} for x in qs]})

    def export_devices_csv(self, request):
        qs = Device.objects.all().select_related("location", "catalog_item")

        if not request.user.is_superuser:
            profile = getattr(request.user, "profile", None)
            if profile and getattr(profile, "aimag", None):
                qs = qs.filter(location__aimag_ref=profile.aimag)

        resp = HttpResponse(content_type="text/csv; charset=utf-8")
        resp["Content-Disposition"] = f'attachment; filename="devices_{now().date()}.csv"'
        resp.write("\ufeff")

        w = csv.writer(resp)
        w.writerow(["ID", "Каталог", "Бусад нэр", "Серийн №", "Байршил"])
        for d in qs:
            w.writerow([
                d.id,
                getattr(d.catalog_item, "name_mn", ""),
                getattr(d, "other_name", ""),
                getattr(d, "serial_number", ""),
                getattr(d.location, "name", "") if getattr(d, "location", None) else "",
            ])
        return resp

    class Media:
        js = (
            "admin/inventory/device/device_kind_filter.js",
            "admin/inventory/device/device_location_cascade.js",
        )


class SparePartItemInline(admin.TabularInline):
    model = SparePartItem
    extra = 1


@admin.register(SparePartOrder)
class SparePartOrderAdmin(admin.ModelAdmin):
    list_display = ("order_no", "aimag", "status", "created_at")
    list_filter = ("status", "aimag")
    search_fields = ("order_no", "aimag__name")
    autocomplete_fields = ("aimag",)
    inlines = [SparePartItemInline]
    ordering = ("-created_at",)


@admin.register(SparePartItem)
class SparePartItemAdmin(admin.ModelAdmin):
    list_display = ("order", "part_name", "quantity")
    search_fields = ("part_name", "order__order_no")
    autocomplete_fields = ("order",)


# ============================================================
# ✅ UserProfile
# ============================================================
@admin.register(UserProfile)
class UserProfileAdmin(admin.ModelAdmin):
    list_display = ("user", "role", "aimag", "org", "must_change_password")
    list_filter = ("role", "aimag", "org", "must_change_password")
    search_fields = ("user__username", "user__email", "aimag__name", "org__name")
    autocomplete_fields = ("user", "aimag", "org")


# ============================================================
# ✅ Auth audit log (readonly)
# ============================================================
@admin.register(AuthAuditLog)
class AuthAuditLogAdmin(admin.ModelAdmin):
    list_display = ("created_at", "action", "username", "user", "ip_address")
    list_filter = ("action", "created_at")
    search_fields = ("username", "user__username", "ip_address", "user_agent")
    autocomplete_fields = ("user",)
    ordering = ("-created_at",)
    readonly_fields = (
        "user", "username", "action", "ip_address", "user_agent", "created_at", "extra"
    )
