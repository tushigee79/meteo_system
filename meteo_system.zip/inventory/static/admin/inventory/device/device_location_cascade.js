(function () {
  function $(sel) { return document.querySelector(sel); }

  function init() {
    const aimagEl = $("#id_aimag");
    const sumEl = $("#id_sumduureg");
    const locEl = $("#id_location");
    if (!aimagEl || !sumEl || !locEl) return;

    function clearSelect(el) {
      el.innerHTML = "";
      const o = document.createElement("option");
      o.value = "";
      o.textContent = "---------";
      el.appendChild(o);
    }

    function loadSums() {
      clearSelect(sumEl);
      clearSelect(locEl);

      const aimagId = aimagEl.value;
      if (!aimagId) return;

      fetch("sums-by-aimag/?aimag_id=" + encodeURIComponent(aimagId))
        .then((r) => r.json())
        .then((data) => {
          (data.results || []).forEach((it) => {
            const o = document.createElement("option");
            o.value = it.id;
            o.textContent = it.text;
            sumEl.appendChild(o);
          });
        })
        .catch(() => {});
    }

    function loadLocations() {
      clearSelect(locEl);
      const sumId = sumEl.value;
      if (!sumId) return;

      fetch("locations-by-sum/?sum_id=" + encodeURIComponent(sumId))
        .then((r) => r.json())
        .then((data) => {
          (data.results || []).forEach((it) => {
            const o = document.createElement("option");
            o.value = it.id;
            o.textContent = it.text;
            locEl.appendChild(o);
          });
        })
        .catch(() => {});
    }

    aimagEl.addEventListener("change", loadSums);
    sumEl.addEventListener("change", loadLocations);

    // edit үед (объект дээр aimag/sum default тавих) — дараа сайжруулж болно
  }

  document.addEventListener("DOMContentLoaded", init);
})();
