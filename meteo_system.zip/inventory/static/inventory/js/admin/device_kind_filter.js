(function () {
  function ready(fn){ if(document.readyState!=="loading"){fn();} else {document.addEventListener("DOMContentLoaded", fn);} }

  ready(function () {
    const kindEl = document.getElementById("id_kind");
    const catEl  = document.getElementById("id_catalog_item");
    if (!kindEl || !catEl) return;

    async function loadCatalog(kind) {
      const url = "./catalog-options/?kind=" + encodeURIComponent(kind || "");
      const r = await fetch(url, {headers: {"X-Requested-With":"XMLHttpRequest"}});
      const data = await r.json();

      const current = catEl.value;
      catEl.innerHTML = "";
      const opt0 = document.createElement("option");
      opt0.value = "";
      opt0.textContent = "---------";
      catEl.appendChild(opt0);

      (data.items || []).forEach(it => {
        const o = document.createElement("option");
        o.value = String(it.id);
        o.textContent = it.text;
        catEl.appendChild(o);
      });

      // боломжтой бол өмнөх сонголтоо хадгална
      if ([...catEl.options].some(o => o.value === current)) {
        catEl.value = current;
      }
    }

    kindEl.addEventListener("change", () => loadCatalog(kindEl.value));
    // initial
    loadCatalog(kindEl.value);
  });
})();
