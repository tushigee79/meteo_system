# inventory/admin.py
import csv

from django import forms
from django.contrib import admin
from django.core.exceptions import ValidationError
from django.http import HttpRequest, HttpResponse, JsonResponse
from django.shortcuts import redirect
from django.urls import path, reverse

from .models import (
    Aimag, SumDuureg, Organization,
    Location, Device, InstrumentCatalog
)

# -------------------------
# Helper: model field exists?
# -------------------------
def model_has_field(model_cls, field_name: str) -> bool:
    try:
        model_cls._meta.get_field(field_name)
        return True
    except Exception:
        return False


# ============================================================
# Aimag / SumDuureg / Organization
# ============================================================
@admin.register(Aimag)
class AimagAdmin(admin.ModelAdmin):
    search_fields = ("name", "code")
    list_display = ("name", "code")


@admin.register(SumDuureg)
class SumDuuregAdmin(admin.ModelAdmin):
    search_fields = ("name", "code")
    list_display = ("name", "aimag", "code")
    list_filter = ("aimag",)
    autocomplete_fields = ("aimag",)


@admin.register(Organization)
class OrganizationAdmin(admin.ModelAdmin):
    search_fields = ("name",)
    list_display = ("name", "org_type", "aimag")
    list_filter = ("org_type", "aimag")
    autocomplete_fields = ("aimag",)


# ============================================================
# Location Admin (map + template buttons + dependent sums)
# ============================================================
@admin.register(Location)
class LocationAdmin(admin.ModelAdmin):
    # ✅ Хэрвээ чи custom changelist template ашигладаг бол:
    # change_list_template = "admin/inventory/location/change_list.html"

    search_fields = ("name", "wmo_index", "district_name")
    list_display = ("name", "location_type", "aimag_ref", "district_name", "wmo_index")
    list_filter = ("location_type", "aimag_ref", "district_name")
    autocomplete_fields = ("aimag_ref", "sum_ref", "owner_org")
    ordering = ("name",)

    class Media:
        js = ("inventory/js/admin/location_sum_filter.js",)

    def get_urls(self):
        urls = super().get_urls()
        custom = [
            # aimag -> sum options (Location form дээр sum_ref шүүх)
            path(
                "sum-options/",
                self.admin_site.admin_view(self.sum_options_view),
                name="location_sum_options",
            ),

            # Template дээр чинь ашиглагддаг 2 нэрийг БАТАЛГААТ гаргаж өгнө
            path(
                "download-template/",
                self.admin_site.admin_view(self.download_aimag_template_view),
                name="download_aimag_template",
            ),
            path(
                "device-import/",
                self.admin_site.admin_view(self.device_import_alias_view),
                name="inventory_device_import_csv",
            ),

            # Газрын зураг тусдаа view (Location list дээр “Газрын зураг” товчоор орно)
            path(
                "map/",
                self.admin_site.admin_view(self.location_map_view),
                name="inventory_location_map",
            ),
        ]
        return custom + urls

    def sum_options_view(self, request: HttpRequest):
        aimag_id = (request.GET.get("aimag_id") or "").strip()
        qs = SumDuureg.objects.all()
        if aimag_id.isdigit():
            qs = qs.filter(aimag_id=int(aimag_id))
        qs = qs.order_by("name")[:2000]
        return JsonResponse({"items": [{"id": s.id, "text": s.name} for s in qs]})

    def download_aimag_template_view(self, request: HttpRequest):
        resp = HttpResponse(content_type="text/csv; charset=utf-8")
        resp["Content-Disposition"] = 'attachment; filename="location_template.csv"'
        resp.write("\ufeff".encode("utf8"))

        w = csv.writer(resp)
        w.writerow([
            "name", "location_type", "aimag_ref", "sum_ref",
            "latitude", "longitude", "wmo_index", "district_name"
        ])
        w.writerow(["Жишээ станц", "AWS", "Улаанбаатар", "Баянзүрх", "47.92", "106.92", "12345", "Баянзүрх"])
        return resp

    def device_import_alias_view(self, request: HttpRequest):
        # Түр: Device changelist руу үсрүүлнэ
        return redirect(reverse("admin:inventory_device_changelist"))

    def location_map_view(self, request: HttpRequest):
        """
        ✅ Газрын зураг (3 өнгө) – хамгийн энгийн, эвдрэхгүй хувилбар.
        Чи хүсвэл дараа нь өнгө/legend-ээ яг хүссэнээр чинь өргөтгөнө.
        """
        # Location-уудаа JSON болгон өгнө
        rows = []
        for loc in Location.objects.all().select_related("aimag_ref", "sum_ref"):
            rows.append({
                "id": loc.id,
                "name": getattr(loc, "name", ""),
                "lat": float(loc.latitude) if getattr(loc, "latitude", None) else None,
                "lon": float(loc.longitude) if getattr(loc, "longitude", None) else None,
                "type": getattr(loc, "location_type", ""),
                "aimag": str(getattr(loc, "aimag_ref", "") or ""),
                "sum": str(getattr(loc, "sum_ref", "") or ""),
            })

        # ✅ template хэрэглэхгүйгээр шууд HTML буцаана (admin/change_list.html байхгүй ч ажиллана)
        # (Leaflet CDN ашиглана)
        html = f"""
<!doctype html>
<html lang="mn">
<head>
  <meta charset="utf-8"/>
  <title>Станцуудын газрын зураг</title>
  <link rel="stylesheet" href="https://unpkg.com/leaflet@1.9.4/dist/leaflet.css"/>
  <script src="https://unpkg.com/leaflet@1.9.4/dist/leaflet.js"></script>
  <style>
    body {{ margin: 0; font-family: sans-serif; }}
    #map {{ height: 92vh; }}
    .bar {{ padding: 10px 12px; background: #111827; color: #fff; }}
    .legend span {{ display:inline-block; width:12px; height:12px; margin-right:6px; border-radius:3px; }}
  </style>
</head>
<body>
  <div class="bar">
    <b>Станцуудын газрын зураг</b>
    &nbsp; | &nbsp;
    <a style="color:#93c5fd" href="{reverse('admin:inventory_location_changelist')}">← Буцах (Location жагсаалт)</a>
    <span class="legend" style="margin-left:18px">
      <span style="background:#22c55e"></span>AWS
      <span style="background:#3b82f6; margin-left:10px"></span>METEO
      <span style="background:#f59e0b; margin-left:10px"></span>HYDRO
      <span style="background:#ef4444; margin-left:10px"></span>Other
    </span>
  </div>
  <div id="map"></div>

  <script>
    const DATA = {rows};
    const map = L.map('map').setView([47.9, 106.9], 5);
    L.tileLayer('https://{{s}}.tile.openstreetmap.org/{{z}}/{{x}}/{{y}}.png', {{
      maxZoom: 18,
      attribution: '&copy; OpenStreetMap'
    }}).addTo(map);

    function colorFor(t) {{
      const x = (t || '').toUpperCase();
      if (x.includes('AWS')) return '#22c55e';
      if (x.includes('METEO')) return '#3b82f6';
      if (x.includes('HYDRO')) return '#f59e0b';
      return '#ef4444';
    }}

    for (const r of DATA) {{
      if (!r.lat || !r.lon) continue;
      const c = colorFor(r.type);
      const m = L.circleMarker([r.lat, r.lon], {{
        radius: 6,
        color: c,
        fillColor: c,
        fillOpacity: 0.9,
        weight: 2
      }}).addTo(map);
      m.bindPopup(
        `<b>${{r.name}}</b><br/>${{r.type || ''}}<br/>${{r.aimag || ''}} ${{r.sum ? ('- ' + r.sum) : ''}}`
      );
    }}
  </script>
</body>
</html>
"""
        return HttpResponse(html)


# ============================================================
# Device Admin (kind -> catalog + aimag/sum -> location)
# ============================================================
class DeviceAdminForm(forms.ModelForm):
    # ✅ UI-д нэмэгдэж харагдана (DB-д хадгалахгүй)
    aimag_pick = forms.ModelChoiceField(
        queryset=Aimag.objects.all().order_by("name"),
        required=False,
        label="Аймаг/Нийслэл",
    )
    sum_pick = forms.ModelChoiceField(
        queryset=SumDuureg.objects.none(),
        required=False,
        label="Сум/Дүүрэг",
    )

    class Meta:
        model = Device
        fields = "__all__"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)

        # 1) kind -> catalog_item (InstrumentCatalog.kind дээр тулж шүүнэ)
        kind = None
        if self.data.get("kind"):
            kind = (self.data.get("kind") or "").strip()
        elif self.instance and getattr(self.instance, "kind", None):
            kind = str(self.instance.kind)

        if "catalog_item" in self.fields:
            qs = InstrumentCatalog.objects.all()
            if kind and model_has_field(InstrumentCatalog, "kind"):
                qs = qs.filter(kind=kind)

            if model_has_field(InstrumentCatalog, "is_active"):
                qs = qs.filter(is_active=True)

            # sort_order байхгүй бол name_mn-р эрэмбэлнэ
            if model_has_field(InstrumentCatalog, "sort_order"):
                qs = qs.order_by("sort_order", "name_mn")
            else:
                qs = qs.order_by("name_mn")

            self.fields["catalog_item"].queryset = qs

        # 2) Аймаг/Сум сонголтоор Location (станц) шүүх
        if self.instance and getattr(self.instance, "location_id", None):
            loc = self.instance.location
            if loc and getattr(loc, "aimag_ref_id", None):
                self.fields["aimag_pick"].initial = loc.aimag_ref_id
                self.fields["sum_pick"].queryset = SumDuureg.objects.filter(
                    aimag_id=loc.aimag_ref_id
                ).order_by("name")
                if getattr(loc, "sum_ref_id", None):
                    self.fields["sum_pick"].initial = loc.sum_ref_id

        aimag_id = (self.data.get("aimag_pick") or "").strip()
        sum_id = (self.data.get("sum_pick") or "").strip()

        if aimag_id.isdigit():
            self.fields["sum_pick"].queryset = SumDuureg.objects.filter(
                aimag_id=int(aimag_id)
            ).order_by("name")

        if "location" in self.fields:
            loc_qs = Location.objects.all()
            if sum_id.isdigit():
                loc_qs = loc_qs.filter(sum_ref_id=int(sum_id))
            elif aimag_id.isdigit():
                loc_qs = loc_qs.filter(aimag_ref_id=int(aimag_id))
            self.fields["location"].queryset = loc_qs.order_by("name")

    def clean(self):
        cleaned = super().clean()
        # OTHER сонгосон бол other_name заавал
        if hasattr(Device, "Kind") and cleaned.get("kind") == getattr(Device.Kind, "OTHER", None):
            other = (cleaned.get("other_name") or "").strip()
            if not other:
                raise ValidationError({"other_name": "“Бусад” сонгосон бол нэр заавал бөглөнө."})
        return cleaned


@admin.register(Device)
class DeviceAdmin(admin.ModelAdmin):
    form = DeviceAdminForm

    list_display = ("serial_number", "catalog_item", "location", "status", "installation_date")
    list_filter = ("status", "kind", "location__aimag_ref")
    search_fields = ("serial_number", "catalog_item__name_mn", "other_name", "location__name")

    # ⚠️ location autocomplete-ийг унтраана (dependent dropdown хийхэд хэрэгтэй)
    autocomplete_fields = ()

    class Media:
        js = (
            "inventory/js/admin/device_kind_filter.js",
            "inventory/js/admin/device_location_dependent.js",
        )

    def get_urls(self):
        urls = super().get_urls()
        custom = [
            # kind -> catalog options (AJAX)
            path(
                "catalog-options/",
                self.admin_site.admin_view(self.catalog_options_view),
                name="inventory_device_catalog_options",
            ),
            # aimag -> sum options (AJAX)
            path(
                "sum-options/",
                self.admin_site.admin_view(self.sum_options_view),
                name="inventory_device_sum_options",
            ),
            # (optional) aimag/sum -> location options (AJAX)
            path(
                "location-options/",
                self.admin_site.admin_view(self.location_options_view),
                name="inventory_device_location_options",
            ),
            # CSV export
            path(
                "export-csv/",
                self.admin_site.admin_view(self.export_devices_csv_view),
                name="export_devices_csv",
            ),
        ]
        return custom + urls

    def catalog_options_view(self, request: HttpRequest):
        kind = (request.GET.get("kind") or "").strip()
        qs = InstrumentCatalog.objects.all()

        if kind and model_has_field(InstrumentCatalog, "kind"):
            qs = qs.filter(kind=kind)

        if model_has_field(InstrumentCatalog, "is_active"):
            qs = qs.filter(is_active=True)

        if model_has_field(InstrumentCatalog, "sort_order"):
            qs = qs.order_by("sort_order", "name_mn")
        else:
            qs = qs.order_by("name_mn")

        items = []
        for x in qs[:2000]:
            code = getattr(x, "code", "") or ""
            name = getattr(x, "name_mn", "") or str(x)
            items.append({"id": x.id, "text": f"{name} ({code})" if code else name})
        return JsonResponse({"items": items})

    def sum_options_view(self, request: HttpRequest):
        aimag_id = (request.GET.get("aimag_id") or "").strip()
        qs = SumDuureg.objects.all()
        if aimag_id.isdigit():
            qs = qs.filter(aimag_id=int(aimag_id))
        qs = qs.order_by("name")[:2000]
        return JsonResponse({"items": [{"id": s.id, "text": s.name} for s in qs]})

    def location_options_view(self, request: HttpRequest):
        aimag_id = (request.GET.get("aimag_id") or "").strip()
        sum_id = (request.GET.get("sum_id") or "").strip()

        qs = Location.objects.all()
        if sum_id.isdigit():
            qs = qs.filter(sum_ref_id=int(sum_id))
        elif aimag_id.isdigit():
            qs = qs.filter(aimag_ref_id=int(aimag_id))

        qs = qs.order_by("name")[:2000]
        return JsonResponse({"items": [{"id": l.id, "text": l.name} for l in qs]})

    def export_devices_csv_view(self, request: HttpRequest):
        qs = self.get_queryset(request).select_related("location", "catalog_item")

        resp = HttpResponse(content_type="text/csv; charset=utf-8")
        resp["Content-Disposition"] = 'attachment; filename="devices_export.csv"'
        resp.write("\ufeff".encode("utf8"))

        w = csv.writer(resp)
        w.writerow(["ID", "Серийн дугаар", "Төрөл", "Каталог", "Бусад нэр", "Байршил", "Статус", "Суулгасан огноо"])

        for d in qs:
            cat = getattr(d.catalog_item, "name_mn", "") if d.catalog_item else ""
            w.writerow([
                d.pk,
                getattr(d, "serial_number", ""),
                getattr(d, "kind", ""),
                cat,
                getattr(d, "other_name", ""),
                str(getattr(d, "location", "")),
                getattr(d, "status", ""),
                getattr(d, "installation_date", "") or "",
            ])
        return resp
